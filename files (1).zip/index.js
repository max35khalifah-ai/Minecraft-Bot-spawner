require('dotenv').config();
const readline = require('readline');
const mineflayer = require('mineflayer');
const { pathfinder, Movements } = require('mineflayer-pathfinder');
const voice = require('./voice');
const commands = require('./commands');

const bot = mineflayer.createBot({
  host: process.env.MC_HOST || 'localhost',
  port: parseInt(process.env.MC_PORT || '25565', 10),
  username: process.env.MC_USERNAME || 'VoiceBot',
  version: process.env.MC_VERSION || undefined,
});

bot.loadPlugin(pathfinder);

bot.once('spawn', () => {
  const movements = new Movements(bot);
  bot.pathfinder.setMovements(movements);
  console.log('Bot spawned. Voice control ready.\n');
  console.log('  r          -> start/stop recording a voice command');
  console.log('  t <text>   -> run a text command directly (no mic needed)');
  console.log('  q          -> quit\n');
});

bot.on('kicked', (reason) => console.log('Kicked:', reason));
bot.on('error', (err) => console.log('Bot error:', err.message));

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.on('line', async (line) => {
  const input = line.trim();

  if (input === 'q') {
    bot.quit();
    process.exit(0);
  } else if (input === 'r') {
    if (voice.isRecording()) {
      try {
        const text = await voice.stopRecordingAndTranscribe();
        if (text) {
          await commands.execute(bot, text);
        } else {
          console.log('(heard nothing)');
        }
      } catch (err) {
        console.error('Transcription failed:', err.message);
      }
    } else {
      voice.startRecording();
    }
  } else if (input.startsWith('t ')) {
    await commands.execute(bot, input.slice(2));
  } else if (input.length) {
    console.log('Unknown input. Use "r", "t <text>", or "q".');
  }
});
