const fs = require('fs');
const path = require('path');
const os = require('os');
const mic = require('mic');
const fetch = require('node-fetch');
const FormData = require('form-data');
const { spawnSync } = require('child_process');

const TMP_WAV = path.join(os.tmpdir(), 'mc-voice-bot-clip.wav');

let micInstance = null;
let micInputStream = null;
let fileStream = null;
let recording = false;

function startRecording() {
  if (recording) return;
  recording = true;

  micInstance = mic({
    rate: '16000',
    channels: '1',
    fileType: 'wav',
  });
  micInputStream = micInstance.getAudioStream();
  fileStream = fs.createWriteStream(TMP_WAV);
  micInputStream.pipe(fileStream);
  micInputStream.on('error', (err) => console.error('[mic] error:', err.message));

  micInstance.start();
  console.log('Recording... type "r" and press Enter again to stop.');
}

function stopRecordingAndTranscribe() {
  return new Promise((resolve, reject) => {
    if (!recording || !micInstance) {
      resolve(null);
      return;
    }
    recording = false;
    console.log('Transcribing...');

    fileStream.on('finish', async () => {
      try {
        const text = await transcribe(TMP_WAV);
        resolve(text);
      } catch (err) {
        reject(err);
      }
    });

    micInstance.stop();
    fileStream.end();
  });
}

async function transcribe(wavPath) {
  const mode = (process.env.WHISPER_MODE || 'api').toLowerCase();
  return mode === 'local' ? transcribeLocal(wavPath) : transcribeApi(wavPath);
}

async function transcribeApi(wavPath) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not set (or set WHISPER_MODE=local in .env)');
  }
  const form = new FormData();
  form.append('file', fs.createReadStream(wavPath));
  form.append('model', 'whisper-1');

  const res = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, ...form.getHeaders() },
    body: form,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Whisper API error ${res.status}: ${errText}`);
  }
  const data = await res.json();
  return (data.text || '').trim();
}

function transcribeLocal(wavPath) {
  const bin = process.env.WHISPER_CPP_BIN;
  const model = process.env.WHISPER_CPP_MODEL;
  if (!bin || !model) {
    throw new Error('WHISPER_CPP_BIN and WHISPER_CPP_MODEL must be set for local mode (see README.md)');
  }
  const outBase = wavPath.replace(/\.wav$/, '');
  const result = spawnSync(bin, ['-m', model, '-f', wavPath, '-otxt', '-of', outBase, '-nt'], {
    encoding: 'utf8',
  });
  if (result.status !== 0) {
    throw new Error(`whisper.cpp failed: ${result.stderr || result.error}`);
  }
  const txtPath = `${outBase}.txt`;
  if (!fs.existsSync(txtPath)) {
    throw new Error('whisper.cpp produced no output file');
  }
  return fs.readFileSync(txtPath, 'utf8').trim();
}

module.exports = {
  startRecording,
  stopRecordingAndTranscribe,
  isRecording: () => recording,
};
