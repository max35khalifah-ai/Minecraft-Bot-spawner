const { goals } = require('mineflayer-pathfinder');
const { GoalNear, GoalFollow } = goals;

let homePosition = null;
let activeInterval = null;

function clearActiveInterval() {
  if (activeInterval) {
    clearInterval(activeInterval);
    activeInterval = null;
  }
}

function stopAll(bot) {
  bot.pathfinder.setGoal(null);
  clearActiveInterval();
}

function ownerEntity(bot) {
  const ownerName = process.env.MC_OWNER_USERNAME;
  if (ownerName && bot.players[ownerName] && bot.players[ownerName].entity) {
    return bot.players[ownerName].entity;
  }
  // Fall back to the nearest player if the configured owner isn't visible.
  return bot.nearestEntity((e) => e.type === 'player');
}

async function execute(bot, rawText) {
  const text = rawText.toLowerCase().trim();
  if (!text) return;
  console.log(`Heard: "${rawText}"`);

  let m;

  // Run a raw Minecraft/server command: "run /time set day", "command gamemode creative"
  if ((m = text.match(/^(?:run|command|execute)\s+\/?(.+)/))) {
    bot.chat('/' + m[1].trim());
    return;
  }

  // "go to 100 64 -30" / "walk to 100 64 -30"
  if ((m = text.match(/^(?:go|walk|move)\s+to\s+(-?\d+)[,\s]+(-?\d+)[,\s]+(-?\d+)/))) {
    const [, x, y, z] = m;
    stopAll(bot);
    bot.pathfinder.setGoal(new GoalNear(parseInt(x, 10), parseInt(y, 10), parseInt(z, 10), 1));
    bot.chat(`Heading to ${x}, ${y}, ${z}`);
    return;
  }

  // "come here" / "come to me"
  if (/^come (here|to me|on)/.test(text)) {
    const target = ownerEntity(bot);
    if (!target) return bot.chat("I can't see you.");
    stopAll(bot);
    bot.pathfinder.setGoal(new GoalNear(target.position.x, target.position.y, target.position.z, 2));
    return;
  }

  // "follow me"
  if (/^follow me/.test(text)) {
    const target = ownerEntity(bot);
    if (!target) return bot.chat("I can't see you.");
    stopAll(bot);
    bot.pathfinder.setGoal(new GoalFollow(target, 2), true);
    bot.chat('Following you.');
    return;
  }

  // "stop"
  if (/^stop/.test(text)) {
    stopAll(bot);
    bot.chat('Stopped.');
    return;
  }

  // "attack" / "kill" nearest hostile mob
  if (/^(attack|kill)/.test(text)) {
    const mob = bot.nearestEntity(
      (e) => e.type === 'mob' && e.mobType && e.position.distanceTo(bot.entity.position) < 16
    );
    if (!mob) return bot.chat('No mobs nearby.');
    stopAll(bot);
    bot.pathfinder.setGoal(new GoalNear(mob.position.x, mob.position.y, mob.position.z, 1));
    activeInterval = setInterval(() => {
      if (!mob.isValid) return clearActiveInterval();
      if (bot.entity.position.distanceTo(mob.position) < 3) bot.attack(mob);
    }, 500);
    setTimeout(clearActiveInterval, 15000);
    return;
  }

  // "mine" / "dig" the block underfoot
  if (/^(mine|dig)/.test(text)) {
    const block = bot.blockAt(bot.entity.position.offset(0, -1, 0));
    if (block && bot.canDigBlock(block)) {
      try {
        await bot.dig(block);
        bot.chat('Mined it.');
      } catch (err) {
        bot.chat("Couldn't mine that.");
      }
    } else {
      bot.chat("Can't mine that.");
    }
    return;
  }

  // "jump"
  if (/^jump/.test(text)) {
    bot.setControlState('jump', true);
    setTimeout(() => bot.setControlState('jump', false), 300);
    return;
  }

  // "set home" / "go home"
  if (/^set home/.test(text)) {
    homePosition = bot.entity.position.clone();
    bot.chat('Home set.');
    return;
  }
  if (/^go home/.test(text)) {
    if (!homePosition) return bot.chat('No home set yet.');
    stopAll(bot);
    bot.pathfinder.setGoal(new GoalNear(homePosition.x, homePosition.y, homePosition.z, 1));
    return;
  }

  // "equip diamond sword" / "drop dirt"
  if ((m = text.match(/^equip (.+)/))) {
    const item = findItem(bot, m[1]);
    if (!item) return bot.chat("I don't have that.");
    await bot.equip(item, 'hand');
    bot.chat(`Equipped ${item.name}.`);
    return;
  }
  if ((m = text.match(/^drop (.+)/))) {
    const item = findItem(bot, m[1]);
    if (!item) return bot.chat("I don't have that.");
    await bot.tossStack(item);
    return;
  }

  // "inventory" / "what's in your inventory"
  if (/^(inventory|what.?s in your inventory)/.test(text)) {
    const items = bot.inventory.items().map((i) => `${i.count}x ${i.name}`);
    bot.chat(items.length ? items.join(', ') : 'Inventory is empty.');
    return;
  }

  // "say hello everyone" -> plain chat message
  if ((m = text.match(/^say (.+)/))) {
    bot.chat(m[1]);
    return;
  }

  // Fallback: whatever was said, just send it to chat.
  bot.chat(rawText);
}

function findItem(bot, name) {
  const needle = name.trim().replace(/\s+/g, '_');
  return bot.inventory.items().find((i) => i.name.includes(needle));
}

module.exports = { execute };
