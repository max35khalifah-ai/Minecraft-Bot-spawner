# mc-voice-bot

A Minecraft bot (built on [mineflayer](https://github.com/PrismarineJS/mineflayer)) that you control by
voice. You talk, [Whisper](https://openai.com/research/whisper) transcribes it, and a small parser turns
the text into bot actions — walking somewhere, following you, fighting, mining, running raw server
commands, and more.

This runs on your own machine (it needs a microphone and a connection to a Minecraft server), so it
can't run inside this chat — download the folder and run it locally.

## 1. Prerequisites

- **Node.js 18+**
- **A Minecraft Java Edition server** you can connect to (a local singleplayer world with "Open to LAN",
  or any server where the bot's account is allowed to join)
- **`sox`**, required by the `mic` package to capture microphone audio:
  - macOS: `brew install sox`
  - Debian/Ubuntu: `sudo apt install sox`
  - Windows: install [SoX](https://sourceforge.net/projects/sox/) and make sure `sox.exe` is on your PATH
- Either an **OpenAI API key** (easiest) or a local **whisper.cpp** build (free, offline) — see step 3.

## 2. Install

```bash
cd mc-voice-bot
npm install
cp .env.example .env
```

Edit `.env`:
- `MC_HOST` / `MC_PORT` / `MC_USERNAME` / `MC_VERSION` — your server details
- `MC_OWNER_USERNAME` — your in-game name, so "come here" / "follow me" know who you are

## 3. Set up Whisper transcription

**Option A — OpenAI API (simplest):**
Set `WHISPER_MODE=api` and put your key in `OPENAI_API_KEY`. Costs roughly $0.006/minute of audio.

**Option B — local whisper.cpp (free, offline):**
1. Build [whisper.cpp](https://github.com/ggml-org/whisper.cpp) and download a model (e.g. `ggml-base.en.bin`).
2. Set `WHISPER_MODE=local`, and point `WHISPER_CPP_BIN` / `WHISPER_CPP_MODEL` at the binary and model file.

## 4. Run it

```bash
npm start
```

Once the bot spawns, in the same terminal:

| Type            | Effect                                              |
|-----------------|------------------------------------------------------|
| `r` + Enter      | Start recording. Type `r` + Enter again to stop and transcribe it. |
| `t <text>` + Enter | Skip the mic and run text directly — good for testing. |
| `q` + Enter      | Quit.                                                |

Example session:
```
> r
Recording... type "r" and press Enter again to stop.
> r
Transcribing...
Heard: "walk to 100 64 -30"
> t follow me
Heard: "follow me"
Following you.
```

## 5. Voice commands it understands

- **"go to 100 64 -30"** / "walk to ..." / "move to ..." — pathfind to coordinates
- **"come here"** / "come to me" — walk to you
- **"follow me"** — continuously follow you
- **"stop"** — cancel movement
- **"attack"** / "kill" — fight the nearest hostile mob
- **"mine"** / "dig" — dig the block directly underfoot
- **"jump"**
- **"set home"** / "go home" — remember a spot, return to it later
- **"equip diamond sword"** / "equip <item>"
- **"drop <item>"**
- **"inventory"** — bot lists what it's carrying
- **"say hello everyone"** — plain chat message
- **"run /time set day"** / "command gamemode creative" — sends anything after as a raw `/command`
- Anything else is just sent to chat as-is, so you can freely chat through the bot too.

## 6. Extending it

Everything the bot can *do* lives in `commands.js` — it's a plain list of `if (text.matches(...))`
blocks. To add a new voice command, add another block there; you have the full `bot` (mineflayer)
object to call things like `bot.chat`, `bot.dig`, `bot.attack`, `bot.pathfinder.setGoal`, etc. Some
ideas to try next:
- Place blocks ("build a wall", "place a block")
- Collect specific items ("collect wood", "get 10 cobblestone")
- Multiple named home points instead of one
- A wake word so you don't need to press `r` manually, using a small always-on VAD
- Read chat messages back to you with text-to-speech
